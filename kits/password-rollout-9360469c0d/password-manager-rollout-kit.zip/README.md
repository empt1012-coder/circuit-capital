# How to use this kit

This kit is for a small business or team of about 5 to 50 people moving to a company password manager. It works with any mainstream product: Bitwarden, 1Password, NordPass, Keeper or others.

**What's inside**

1. Pick-a-manager checklist
2. Two-week rollout plan, by day
3. Admin setup checklist (MFA, SSO, recovery)
4. Staff announcement email template
5. Staff how-to one-pager
6. Shared-vault structure template
7. Offboarding checklist
8. One-page password policy template
9. FAQ for staff pushback

Plus editable copies of every section (Markdown and Word) and a rollout tracker (Excel and CSV).

**Who should run it.** One rollout lead with admin rights, plus a backup admin. You do not need an IT department.

**How long.** Ten working days, about an hour a day for the lead and 30 minutes total for each staff member.

**License.** For use inside one organization. Edit the templates freely. Please don't resell or republish them.

**Not advice for your situation.** This is a practical checklist, not legal, compliance or security certification advice. Check each product's current features and prices on the vendor's own page.

Questions or corrections: contact form at circuits.fit/contact.html.

*Disclosure: Circuit & Capital is a Nord Security affiliate and may earn a commission if you buy NordPass through our site. The kit is vendor-neutral and every step works with any product above.*
