# 4. Staff announcement email template

Send on day 6 from the owner or manager, not from IT alone. Edit the bracketed parts.

---

**Subject:** We're moving our work passwords to [Product] this week

Hi all,

Starting today we're using [Product] to store and share work passwords. It replaces [the shared spreadsheet / passwords in notes / sticky notes / browser saved passwords for work accounts].

**Why:** most break-ins at small companies start with a reused or shared password. This gives each of you one strong password to remember, fills in the rest for you, and lets us cut off access cleanly when someone leaves.

**What you need to do (about 20 minutes, by [Wednesday date]):**

1. Accept the invite from [Product] in your inbox.
2. Create your master password. Use four or more random words. Do not reuse any other password. Write it on paper and keep it at home until it's memorized.
3. Turn on two-step sign-in with an authenticator app.
4. Install the browser extension and the phone app.
5. Import the work passwords saved in your browser, then turn off the browser's own password saving for work.

The attached one-page guide walks through each step.

**Drop-in help:** [Tuesday, time, room or call link]. Bring your laptop and phone.

**What doesn't change:** your personal passwords are yours. You can keep them in a free personal account or your own manager, not in the company account.

**Who to ask:** [Rollout lead name, email, phone].

The old [password spreadsheet] will be deleted on [Thursday date].

Thanks,
[Name]
