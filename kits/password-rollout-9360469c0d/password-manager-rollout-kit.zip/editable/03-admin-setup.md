# 3. Admin setup checklist

Do these in order on day 2. Names of settings differ by product; the idea is the same.

## Accounts and recovery

1. [ ] Create the organization with a role mailbox (for example it@ or admin@), not one person's inbox.
2. [ ] Two admins minimum, both with their own accounts. Never share an admin login.
3. [ ] MFA on both admin accounts with an authenticator app or a hardware security key. Register a second factor for each.
4. [ ] Save the organization's recovery codes / emergency kit. Print two copies, seal them, store one in the office safe and one off-site (owner's home safe or bank box). Never store them only inside the password manager.
5. [ ] Turn on admin or account recovery for staff (the feature that lets an admin restore access to a member who forgets a master password), if the product offers it. Write down who can approve a recovery.
6. [ ] Set up emergency access / break-glass so the owner can reach critical vaults if both admins are unavailable.

## Sign-in and identity

7. [ ] If your tier supports SSO, connect it to Microsoft 365 / Entra ID, Google Workspace or Okta. Test with one pilot user before turning it on for all.
8. [ ] If you have provisioning (SCIM or directory sync), connect it so disabling a user in your directory suspends them in the password manager. Test with a dummy user.
9. [ ] If you do not have SSO, require MFA for every member in policy settings.
10. [ ] Set a minimum master password rule: a passphrase of at least 4 random words or 14+ characters. Do not force regular changes.

## Policies

11. [ ] Block or warn on export of company vaults by non-admins.
12. [ ] Set session timeout / auto-lock (for example 15 minutes idle on desktop, 1 minute on mobile).
13. [ ] Decide whether personal items are allowed in the company account. Most small teams say: keep personal passwords in a separate personal account.
14. [ ] Turn on breach monitoring / password health reporting if included.
15. [ ] Turn on the event log and confirm both admins can see it.

## Structure

16. [ ] Create groups that match roles, not people (Finance, Ops, Marketing, Leadership, All staff).
17. [ ] Create shared vaults using the template in section 6.
18. [ ] Move critical shared logins in first and confirm the right groups can see them.
19. [ ] Record everything in the tracker's "Admin setup" sheet with the date and who did it.

## Monthly from here

- [ ] Review the user list against payroll or your HR list.
- [ ] Review the event log for exports and unusual access.
- [ ] Review the weak / reused / breached password report.
