# 1. Pick-a-manager checklist

Use this before you buy anything. Most small teams can decide in an afternoon. Score each product you are considering against the same list, and write down the answers you got from the vendor's own pricing and security pages.

## Must-haves (if any answer is "no", drop it)

- [ ] End-to-end encryption: the vendor cannot read your vault contents.
- [ ] Shared vaults or collections with per-group permissions (view, edit, manage).
- [ ] Admin can remove a user and revoke their access to shared items in one step.
- [ ] Works on every platform your staff use: Windows, macOS, iOS, Android, and the browsers you allow.
- [ ] MFA on the account itself, including an authenticator app or security key (not SMS only).
- [ ] Account recovery for staff that does not depend on a single person remembering a password.
- [ ] Export of your data in a readable format (CSV or JSON), so you can leave later.
- [ ] A current independent security audit or SOC 2 Type 2 report you can ask for.

## Fit questions (score 0-2 each)

| Question | Option A | Option B | Option C |
|---|---|---|---|
| SSO with what you already use (Microsoft 365 / Entra ID, Google Workspace, Okta)? Which tier? | | | |
| Automatic user provisioning (SCIM or directory sync)? Which tier? | | | |
| Event log of who viewed or changed shared items? | | | |
| Policy controls (master password rules, MFA required, block export)? | | | |
| Emergency access / break-glass for the owner? | | | |
| Import from browsers and from your current spreadsheet or tool? | | | |
| Price per user per month, billed yearly, for the tier you actually need | | | |
| Minimum seats, and what happens above 10 users | | | |
| Free personal / family plan for staff (nice perk, not required) | | | |
| Trial length and refund window | | | |

## Shortlist to look at

Start with three. These are the names small firms most often compare; check current tiers and prices on each vendor's own page.

- **Bitwarden.** Open source, a free plan for individuals and a low-cost Teams plan; directory sync and SCIM are included lower in the price list than most. A strong default if price and openness matter most.
- **1Password.** Polished apps and good admin tools; identity-provider integrations sit on the Business tier.
- **NordPass Business.** Simple admin console, breach monitoring and password health; Entra ID and Okta SSO are on the Enterprise tier.
- **Keeper.** Strong compliance features; SSO is an add-on or higher tier.

*Disclosure: Circuit & Capital is a Nord Security affiliate. If you buy NordPass through a link on circuits.fit we may earn a commission. Nothing in this kit depends on which product you pick, and every checklist works with any of the above.*

## Decision rule

1. Drop anything that fails a must-have.
2. If you need leavers cut off automatically from Microsoft 365 or Google, pick the cheapest tier that gives SSO plus provisioning, and compare only those prices.
3. Otherwise pick the one your least technical staff member found easiest during the trial. Adoption beats features.
