# 6. Shared-vault structure template

Group by who needs access, not by app type. Fewer vaults is better: most teams of 5-50 need 5-8. Give access to groups, never to individuals, so a role change is one click.

| Vault | Contents (examples) | Group: access | Owner |
|---|---|---|---|
| Leadership - Critical | Bank, payroll provider, domain registrar, DNS, cloud root accounts, tax portal | Leadership: manage | Owner |
| IT Admin | Microsoft 365 / Google admin, firewall, Wi-Fi admin, backup console, password manager break-glass notes | IT admins: manage | IT lead |
| Finance | Accounting software, expense tool, supplier portals, card portals | Finance: edit, Leadership: view | Finance lead |
| Operations | Shipping, scheduling, facilities, alarm codes, vendor portals | Ops: edit | Ops lead |
| Marketing & Social | Website CMS, social accounts, newsletter, ad accounts | Marketing: edit | Marketing lead |
| Sales & Customers | CRM, quoting tool, customer portals | Sales: edit | Sales lead |
| All Staff | Office Wi-Fi guest password, printer, shared low-risk subscriptions | All staff: view | Rollout lead |
| Client - [Name] (one per client if needed) | Logins a client gave you | Client team: edit | Account owner |

## Naming rules

- Item name: `[Service] - [account purpose]`, e.g. `Bank of X - operating account`.
- Put the login URL in the item so autofill works.
- Notes field: who owns the account, which email it's registered to, where MFA codes go.
- For accounts with shared MFA (a single phone), note the phone's location and holder.

## Rules

- Only Leadership and IT Admin vaults hold anything that could move money or lock you out of your domain.
- Each vault has one named owner who reviews membership quarterly.
- Personal accounts and personal passwords do not go in shared vaults.
