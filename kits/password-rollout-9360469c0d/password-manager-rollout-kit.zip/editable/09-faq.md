# 9. FAQ for staff pushback

Short answers you can paste into chat or say at the drop-in session.

**"I already have a system. I remember my passwords."**
Then you're probably reusing some, which is how most accounts get taken over. This means you remember one password instead of dozens, and it fills them in for you.

**"Isn't putting all passwords in one place risky?"**
The vault is encrypted on your device with your master password; the company that runs it can't read it. The risk you're replacing, reused passwords and a shared spreadsheet, is much higher. MFA on the account adds a second lock.

**"Can IT or my boss see my passwords?"**
Not your private items. Admins can see what's in shared vaults they manage and can remove your access, but they can't read your private vault or your master password.

**"What if the password manager company gets hacked?"**
We picked one that encrypts on your device and has an independent audit. Attackers who steal encrypted vaults still need each person's master password, which is why it must be long and unique.

**"What if I forget my master password?"**
Contact [lead]. We've turned on account recovery so an admin can restore your access. Write it on paper and keep it at home until it's memorized.

**"I don't want it on my personal phone."**
You can use only the desktop extension, or the web vault. The phone app is easier, and it doesn't give the company any control of your phone.

**"This is slower."**
For the first week, maybe. After that it's faster: autofill is one click, and you never reset a forgotten password again.

**"Can I keep my personal passwords in it?"**
Keep personal ones in a separate personal account (many products have a free plan). That way they're yours when you leave.

**"Why do I have to turn off the browser's password saving?"**
So work passwords live in one place we can remove when you leave, and so they aren't synced to a personal browser profile.

**"Do I have to do this?"**
Yes. It's company policy from [date]. If something about it doesn't work for your job, tell [lead] and we'll fix it.
