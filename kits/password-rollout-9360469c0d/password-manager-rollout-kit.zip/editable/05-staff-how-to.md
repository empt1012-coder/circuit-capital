# 5. Staff how-to one-pager

Print this or attach it to the announcement email.

## Set up (once, about 20 minutes)

1. **Open the invite** email from [Product] and click Join.
2. **Create your master password.** Four or more random words, e.g. *copper-lantern-river-quietly*. Never reuse it. Never tell anyone, including IT. We cannot see it.
3. **Turn on two-step sign-in** with an authenticator app (Microsoft Authenticator, Google Authenticator, or the one we recommend: [app]).
4. **Save your recovery code / emergency kit** where we told you: [location]. Not in a photo on your phone.
5. **Install the browser extension** on every browser you use for work, and **the phone app**.
6. **Import** your saved work passwords from the browser. Then turn off "offer to save passwords" in the browser.

## Every day

- Log in to a site: click the [Product] icon in the login box, or open the extension and pick the login.
- New account: let [Product] generate the password and save it.
- Need a shared login: it's already in the shared vault for your team. If it isn't, ask [lead]. Don't paste passwords into chat or email.
- Sharing something new: put it in the right shared vault, or ask [lead] to.

## Never

- Never put work passwords in email, chat, sticky notes or spreadsheets.
- Never enter your master password on a page you reached from an email link.
- Never approve a sign-in prompt you didn't start. Call [lead].

## If something goes wrong

- Forgot master password: contact [lead]; we can restore your access with account recovery.
- Lost phone: contact [lead] the same day.
- Think a password leaked: change it in [Product], then tell [lead].
