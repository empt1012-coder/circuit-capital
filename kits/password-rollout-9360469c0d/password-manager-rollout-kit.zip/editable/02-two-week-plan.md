# 2. Two-week rollout plan, by day

Ten working days. Assumes one owner (the "rollout lead", usually the office manager, IT person or founder) spending about an hour a day, and staff spending about 30 minutes total. Track every step in the rollout tracker spreadsheet.

## Week 1: set up and pilot

| Day | Lead does | Staff do | Done when |
|---|---|---|---|
| 1 (Mon) | Pick the product with the checklist (section 1). Start the trial or buy seats. Name a backup admin. | Nothing yet. | Product chosen, two admins named. |
| 2 (Tue) | Run the admin setup checklist (section 3): MFA on both admins, recovery set up, policies set. | Nothing yet. | Admin checklist items 1-15 ticked. |
| 3 (Wed) | Build the shared-vault structure (section 6). Create groups. Move the 10 most important shared logins in (bank, domain registrar, email admin, payroll, website). | Nothing yet. | Critical logins live in shared vaults, old copies flagged for deletion. |
| 4 (Thu) | Invite 2-3 pilot users, including one non-technical person. Sit with them for 15 minutes each. | Pilot users install, set master password, turn on MFA, import browser passwords. | Pilot users can log in to two work sites from the manager. |
| 5 (Fri) | Collect pilot feedback. Fix permissions, write down the three questions people asked. Adjust the staff one-pager (section 5). | Pilot users note anything confusing. | One-pager final. |

## Week 2: everyone in

| Day | Lead does | Staff do | Done when |
|---|---|---|---|
| 6 (Mon) | Send the announcement email (section 4) with the one-pager attached. Send invites. | Read email, accept invite. | All invites sent. |
| 7 (Tue) | Hold a 20-minute drop-in session (call or in person). Answer pushback with the FAQ (section 9). | Install apps and browser extension, set up MFA. | 50%+ accepted. |
| 8 (Wed) | Chase anyone who has not accepted. Check the admin console for users without MFA. | Import browser passwords, move work logins out of notes and spreadsheets. | 80%+ active with MFA. |
| 9 (Thu) | Turn on policies that were in "warn" mode (MFA required, minimum master password). Delete the old shared spreadsheet or document, after a final check that everything is moved. | Turn off the browser's built-in password saving for work profiles. | Old password sheet deleted. |
| 10 (Fri) | Publish the policy (section 8). Add the offboarding checklist (section 7) to your leaver process. Book a 30-day check. | Acknowledge the policy. | 100% active, policy signed, 30-day review booked. |

## Day 30 check

- [ ] Every active staff member is in the console and has MFA on.
- [ ] No one is still on the invite list.
- [ ] The password health / weak password report has been reviewed and the top 10 fixed.
- [ ] One leaver (real or test account) has been offboarded with the checklist.
- [ ] Emergency access has been tested once.
