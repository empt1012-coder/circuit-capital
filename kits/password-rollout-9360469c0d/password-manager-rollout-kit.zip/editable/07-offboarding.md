# 7. Offboarding checklist

Run this on the person's last day (or immediately if the departure is not friendly). Record the date and initials in the tracker's "Offboarding" sheet.

## Within 1 hour of departure

- [ ] Disable the user in your directory (Microsoft 365 / Google). If provisioning is set up, confirm the password manager account shows suspended.
- [ ] If not, suspend or remove the user in the password manager admin console.
- [ ] Transfer any items they owned in shared vaults to the vault owner.
- [ ] Revoke any active sessions in the password manager and email.

## Same day

- [ ] List every shared vault they could see (check the console or the group list).
- [ ] Change the passwords for the highest-risk items in those vaults: banking, payroll, domain/DNS, admin consoles, social accounts. Use the generator.
- [ ] Move or reset any MFA that went to their phone or authenticator.
- [ ] Remove them from any "emergency access" or recovery approver role.
- [ ] Check the event log for exports or unusual views in their last 30 days.

## Within a week

- [ ] Change the remaining passwords in vaults they could edit, starting with anything external (vendor portals, client logins).
- [ ] Confirm the seat is freed or reassigned, so you are not paying for it.
- [ ] Update the vault owner list if they owned a vault.

## Notes

- Shared logins that one person could see are the reason this list exists. The fewer shared logins, the shorter offboarding gets. Prefer individual accounts on each service where you can.
- If the person was an admin, rotate the organization's recovery codes and reprint the emergency kit.
