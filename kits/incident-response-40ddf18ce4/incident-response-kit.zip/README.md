# Incident Response Kit (Circuit & Capital, v1.0, November 2026)

Start with `Incident-Response-Kit.pdf`, section "How to use this kit".

- `Incident-Response-Kit.pdf`: the full kit, ready to print.
- `editable/`: every section as Word (.docx) and Markdown (.md). Edit names, numbers and steps to fit your company.
- `incident-workbook.xlsx`: decision log, affected-systems tracker, contact sheet (our people and outside help).
- `decision-log.csv`, `contact-sheet.csv`: the same logs as plain CSV.

Do this today: fill in the contact sheet (section 7), print it, and keep one paper copy in the office and one at home.

Single-organization license. Please don't resell or republish. Questions or problems: circuits50capital@circuits.fit
