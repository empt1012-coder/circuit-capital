# 8. Decision log

Start this the moment an incident begins. One line per event or decision. Write the time, even if approximate. Do not edit old lines; add a new line if something was wrong. Your insurer, lawyer and any investigator will ask for this record.

**Incident name:** [short name, e.g. "Mailbox - J. Smith - Nov 2026"]
**Incident lead:** [name]  **Started:** [date, time, time zone]
**Insurer claim number:** [ ]  **Police / IC3 report number:** [ ]

| # | Date and time | What we saw or learned | What we did or decided | Who decided | Who did it | Evidence kept (file, photo, screenshot) |
|---|---|---|---|---|---|---|
| 1 | | | | | | |
| 2 | | | | | | |
| 3 | | | | | | |
| 4 | | | | | | |
| 5 | | | | | | |
| 6 | | | | | | |
| 7 | | | | | | |
| 8 | | | | | | |
| 9 | | | | | | |
| 10 | | | | | | |

## Key decisions checklist

Tick when made and record the line number above.

- [ ] Insurer called (line __)
- [ ] Systems isolated or taken offline (line __)
- [ ] Law enforcement or CISA report made (line __)
- [ ] Lawyer consulted on notification (line __)
- [ ] Staff told (line __)
- [ ] Customers or partners told (line __)
- [ ] Recovery approach chosen: restore, rebuild, other (line __)
- [ ] Incident declared over (line __)

## Close-out

**Ended:** [date, time]  **Declared over by:** [name]
**What happened, in three sentences:**
**What we will change:**
