# 9. Sources

All links were checked on November 16, 2026. Guidance changes; check the source page before relying on a specific step.

1. CISA, MS-ISAC, NSA and FBI. *#StopRansomware Guide*, Part 2: Ransomware and Data Extortion Response Checklist, and Contact Information. https://www.cisa.gov/stopransomware/ransomware-guide
2. CISA. *I've Been Hit By Ransomware!* (Ransomware Response Checklist). https://www.cisa.gov/stopransomware/ive-been-hit-ransomware
3. CISA. *Report an incident.* https://www.cisa.gov/report
4. FBI Internet Crime Complaint Center. *Business Email Compromise: The $55 Billion Scam*, PSA I-091124-PSA, September 11, 2024. https://www.ic3.gov/PSA/2024/PSA240911
5. U.S. Treasury, Office of Foreign Assets Control. *Updated Advisory on Potential Sanctions Risks for Facilitating Ransomware Payments*, September 21, 2021. https://ofac.treasury.gov/system/files/126/ofac_ransomware_advisory.pdf
6. Microsoft. *Respond to a compromised email account in Microsoft 365.* https://learn.microsoft.com/en-us/defender-office-365/responding-to-a-compromised-email-account
7. Microsoft. *Revoke user access in an emergency in Microsoft Entra ID.* https://learn.microsoft.com/en-us/entra/identity/users/users-revoke-access
8. Google Workspace Admin Help. *Identify and secure compromised accounts.* https://support.google.com/a/answer/2984349
9. UK National Cyber Security Centre. *Recovering a hacked account.* https://www.ncsc.gov.uk/guidance/recovering-a-hacked-account
10. UK National Cyber Security Centre. *Small Business Guide: Response & Recovery.* https://www.ncsc.gov.uk/collection/small-business-guidance--response-and-recovery
11. U.S. Federal Trade Commission. *Data Breach Response: A Guide for Business.* https://www.ftc.gov/business-guidance/resources/data-breach-response-guide-business
12. National Conference of State Legislatures. *Security Breach Notification Laws.* https://www.ncsl.org/technology-and-communication/security-breach-notification-laws
13. Microsoft Support. *Find or lock a lost Windows device.* https://support.microsoft.com/en-us/account-billing/find-and-lock-a-lost-windows-device-890bf25e-b8ba-d3fe-8253-e98a12f26316
14. Microsoft Learn. *Wipe devices with Microsoft Intune.* https://learn.microsoft.com/en-us/intune/intune-service/remote-actions/devices-wipe
15. Google Workspace Admin Help. *Wipe corporate data from a device.* https://support.google.com/a/answer/173390
16. Apple Support. *Erase a device in Find Devices on iCloud.com.* https://support.apple.com/guide/icloud/erase-a-device-mmfc0ef36f/icloud
17. FBI Internet Crime Complaint Center. https://www.ic3.gov/

## License

Single-organization license. Edit and use these templates inside your company. Please don't resell or republish them.

Circuit & Capital · circuits.fit · Version 1.0, November 2026. This kit is general guidance, not legal, insurance or forensic advice.
