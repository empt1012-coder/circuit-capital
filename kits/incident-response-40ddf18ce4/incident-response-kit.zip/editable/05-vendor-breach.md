# 5. Vendor breach notice playbook

**Covers:** a supplier, software vendor, payroll provider, accountant or IT provider tells you they were breached, or you read about it in the news. You did nothing wrong, but your data or your access may be part of it.

## Step 1: Check the notice is real (first 15 minutes)

- [ ] **Do not click links or call numbers in the notice** until you have checked it. A fake breach notice can itself be phishing.
- [ ] Confirm it on the vendor's own website (type the address yourself) or call your account contact on a number you already have. IC3 recommends verifying requests through a second channel and checking that links match the real domain [4].
- [ ] Save the notice in a folder and start the decision log.

## Step 2: Work out your exposure (first day)

Answer these, from your records first, then by asking the vendor. Template 6.3 has the questions as an email.

- [ ] What data of ours do they hold? Customer records, employee records, payment details, health data, contracts.
- [ ] What access do they have to our systems? Admin accounts, remote access tools, API keys, shared passwords. The FTC's guide says to check what personal information service providers can access and decide whether to change their access [11].
- [ ] What do they say was taken, and over what dates?
- [ ] Are they asking customers to do anything, such as reset passwords or rotate keys?

## Step 3: Reduce your risk now

- [ ] Change passwords you use with that vendor, and anywhere the same password was reused. The NCSC advises changing reused passwords too [9].
- [ ] Rotate API keys or tokens the vendor holds or issued.
- [ ] Disable or narrow the vendor's access to your systems until they confirm it is fixed. The FTC says to verify a provider's claims that vulnerabilities are fixed [11].
- [ ] Warn finance to expect fake invoices or "new bank details" that appear to come from the vendor. Confirm any change by phone on a known number [4].
- [ ] Turn on MFA for your account with the vendor if it is offered.

## Step 4: Decide whether you have to tell anyone

- [ ] If the data involved includes personal information about your customers or staff, ask a lawyer whether you have notification duties. The FTC guide says to check your state's breach notification law, and for health information, the HIPAA Breach Notification Rule and the FTC's Health Breach Notification Rule [11]. NCSL lists state laws [12].
- [ ] Check your contracts with your own customers for clauses that require you to tell them about incidents at your suppliers.
- [ ] Tell your insurer if your policy covers incidents at vendors.

## Step 5: Follow up

- [ ] Put a follow-up date in the decision log, such as 14 days out, to ask the vendor for their final findings.
- [ ] At renewal, ask the vendor what changed. Consider whether to stay.
