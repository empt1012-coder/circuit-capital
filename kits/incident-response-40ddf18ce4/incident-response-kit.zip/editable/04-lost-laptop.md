# 4. Lost or stolen laptop playbook

**Covers:** a work laptop, tablet or phone that is lost, stolen, or not returned by a leaver. The question is not the hardware; it is what can be reached from it.

## Step 1: Get the facts (first 15 minutes)

- [ ] When and where was it last seen? Lost or stolen?
- [ ] Which device: make, model, serial number (from your asset list or the vendor's account page) [13].
- [ ] Was it **encrypted** (BitLocker on Windows, FileVault on Mac) and locked with a password or PIN? The FTC lists checking whether measures such as encryption were enabled as part of a breach investigation [11]. If you do not know, assume not.
- [ ] Which accounts were signed in: email, files, password manager, banking, accounting, remote access?
- [ ] Start the decision log.

## Step 2: Lock it and cut access (first 30 minutes)

- [ ] **Locate and lock** it if you can.
  - Windows with Find My Device: account.microsoft.com/devices, then Find and Lock [13].
  - Mac: icloud.com/find, then select the device [16].
  - Company-managed devices: use your device management tool (for example Microsoft Intune or the Google Admin console) [14][15].
- [ ] **Sign the user out everywhere and reset their password.** Microsoft 365: revoke sessions [7]. Google Workspace: reset the password and revoke OAuth tokens [8].
- [ ] **Remove the device from MFA** if it held an authenticator app, and set the user up with a new method.
- [ ] **Change shared passwords** that were saved on the device and are not in a password manager.

## Step 3: Decide whether to wipe

The decision maker decides, and logs it.

- [ ] **Wipe** if it is unlikely to come back, or if it held sensitive data and was not encrypted.
  - Intune Wipe resets the device to factory settings and removes data, apps and settings [14].
  - The Google Admin console can wipe the work account, the work profile, or all data, depending on the device [15].
  - Apple's Find Devices can erase a Mac or iPhone; if the device is offline, the erase happens the next time it connects [16].
- [ ] **Hold** if it was very likely just misplaced and is encrypted and locked. Set a time limit, such as 24 hours, then wipe.

## Step 4: Report

- [ ] **Stolen:** report to local police and get a report number. Microsoft also recommends telling your insurance company [13].
- [ ] **Personal data on an unencrypted device:** talk to a lawyer about whether breach notification applies. Laws vary by state; NCSL keeps a list of state breach notification laws [12].
- [ ] Tell the carrier if it was a phone, so service can be suspended [16].

## Step 5: Close out

- [ ] Mark the device as lost in your asset list.
- [ ] Replace it with a device that has disk encryption on and is enrolled in device management.
- [ ] If you do not have encryption on every laptop, put that on the list from the review.
