# 3. Hacked email account playbook (Microsoft 365 and Google Workspace)

**Signs:** contacts get email the user never sent; inbox rules that forward mail or move it to odd folders; messages missing from the inbox or sitting in Sent or Deleted; password reset emails nobody asked for; a user locked out; a customer asking why your bank details changed. Microsoft lists these among the common symptoms of a compromised mailbox [6]. The NCSC lists similar signs [9].

The main risk for a small business is not the mailbox itself. It is what the attacker does with it: sending fake invoices or "new bank details" to your customers, or asking your staff to pay someone. The FBI's IC3 calls this business email compromise [4].

## Step 1: Lock the attacker out (first 15 minutes)

Do these from an admin account on a device you trust, not from the affected user's computer.

**Microsoft 365**

- [ ] **Block sign-in** for the user while you investigate. Microsoft recommends disabling the account until the investigation is complete; if you can't, reset the password [6].
- [ ] **Reset the password** to a new, unique one. Do not send the new password to the user by email, since the attacker may still be reading the mailbox [6].
- [ ] **Revoke sessions** so stolen sign-ins stop working. In the Microsoft Entra admin center: Users, All users, select the user, then Revoke sessions on the Overview page [7]. This invalidates active sessions and refresh tokens [6].
- [ ] **Check app passwords.** They are not revoked automatically when you reset the password [6].

**Google Workspace**

- [ ] **Suspend the user.** Google notes that suspending a user resets their sign-in cookies and OAuth tokens [8].
- [ ] **Reset the password** and **revoke OAuth tokens** and any app passwords the user created [8].
- [ ] **Review and wipe** any suspicious mobile devices linked to the account [8].

## Step 2: Remove what the attacker left behind (first hour)

- [ ] **Forwarding.** Look for mailbox forwarding to outside addresses and remove anything you did not set up [6][8].
- [ ] **Inbox rules and filters.** Delete rules that forward, redirect, delete, or move mail to Junk, RSS or other rarely opened folders. In Microsoft 365, hidden rules exist; Microsoft's guide shows how to list them [6]. The NCSC also says to check filters and forwarding rules early [9].
- [ ] **MFA methods.** Remove any phone number or authenticator app the user does not recognise (Microsoft 365) [6]. In Google, check the user's recovery email and phone [8].
- [ ] **Connected apps.** Remove apps the user did not knowingly approve [6][8].
- [ ] **Admin roles.** If the account had admin rights, check for changes and remove roles it should not have [6][8].
- [ ] **Signature and contact details.** Attackers sometimes change these [6].

## Step 3: Find out what they did

- [ ] **Sign-in logs.** Note IP addresses, locations and times of sign-ins you do not recognise. Microsoft 365: Entra sign-in logs and the audit log [6]. Google: user log events in the Admin console [8].
- [ ] **Sent mail.** Check Sent Items and message trace (Microsoft 365) or email log search (Google) for the time window [6][8]. List who received anything.
- [ ] **Payments.** Ask finance whether anyone paid an invoice or changed bank details for a customer or vendor in that window. If money moved, call the bank now and ask for a recall, then file at ic3.gov [4].
- [ ] **Files.** Check OneDrive, SharePoint or Google Drive activity for large downloads or new sharing links [6][8].

## Step 4: Give the account back

- [ ] Re-enable or unsuspend the account with a new password the user changes at first sign-in [6][8].
- [ ] Turn on multifactor authentication. Microsoft highly recommends MFA, and Google recommends security keys over codes [6][8].
- [ ] If the account sent spam, Microsoft 365 may have blocked it from sending. The admin can remove the block from the Restricted entities page [6].
- [ ] Have the user check their own recovery details, contacts and settings. Google has an end-user checklist for this [8].

## Step 5: Tell the people who need to know

- [ ] Warn the people who received fraudulent mail. The NCSC suggests telling contacts so they treat recent messages from the account with suspicion [9]. Template 6.2 is ready to edit.
- [ ] If the mailbox held personal data, such as customer records or HR files, note it in the log and ask a lawyer whether notification rules apply [11][12].
- [ ] Ask staff to confirm any request to change bank details by phone, using a number you already have. IC3 recommends verifying changes to account information through a second channel [4].
