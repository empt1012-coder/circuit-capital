# 6. Message templates

Edit the parts in [brackets]. Have the decision maker approve anything that goes outside the company. Keep messages short and factual: what happened, what you are doing, what you need them to do. Do not guess at causes or numbers you have not confirmed.

## 6.1 Staff alert (say it by phone or in person first, then send if email is safe)

> Subject: Please read: [system] is offline for now
>
> We are dealing with a security problem affecting [system/account]. Until we say otherwise:
>
> - Do not use [system]. Do not try to fix or restart it.
> - Do not open attachments or links in emails about this, even if they look like they come from us. We will phone you if we need anything.
> - Do not post or talk about this outside the company. Send any questions from customers, vendors or reporters to [name].
> - If you notice anything odd on your own computer, unplug the network cable or turn off Wi-Fi and call [name] at [phone].
>
> We will update you by [time]. Thank you.

## 6.2 Customers and contacts after a hacked mailbox

> Subject: Please ignore recent emails from [address]
>
> Between [date/time] and [date/time], someone got into the email account [address] and sent messages we did not write. We have locked them out and secured the account.
>
> If you received an email from that address in that window asking you to open a file, sign in, pay an invoice or change payment details, please do not act on it, and delete it. Our bank details have not changed. If you are unsure about any request from us, call [name] at [phone number you already have on file].
>
> If you already paid or entered a password, please let us know at [phone] and contact your bank.
>
> We are sorry for the trouble.

## 6.3 Questions to a vendor after a breach notice

> Subject: Questions about your [date] security notice
>
> Thanks for your notice dated [date]. To work out what we need to do, please answer the following:
>
> 1. Which of our data or accounts were affected, and over what dates?
> 2. What kinds of data: names, emails, addresses, account numbers, payment details, government IDs, health information, passwords or keys?
> 3. Did the incident involve any access your company has to our systems, or credentials or API keys we gave you?
> 4. Is there anything you need us to do now, such as resetting passwords or rotating keys?
> 5. What have you changed to stop it happening again, and when can you share your final findings?
> 6. Who is our contact for follow-up questions?
>
> Please reply to [name] at [address]. We will also call [vendor contact] on [number on file] to confirm this message is from us.

## 6.4 Short holding line (for a customer who asks)

> We are looking into a security issue affecting [system]. We have taken steps to contain it and are working with [IT provider/our insurer]. We will contact you directly if it affects you or your information.

Before telling customers their personal information was affected, talk to a lawyer. The FTC's data breach guide includes a model notice letter and covers what a notice should say [11].
