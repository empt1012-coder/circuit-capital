# 2. Ransomware playbook

**Signs:** files with strange extensions, files that will not open, a ransom note on screen or in folders, backups failing or missing, a sudden flood of file changes on a shared drive.

This follows the order in CISA's ransomware response checklist, which says to work through the first steps in sequence [1][2].

## Step 1: Isolate (first 15 minutes)

- [ ] Unplug affected computers from the network or turn off their Wi-Fi [1].
- [ ] If several machines or a shared server are affected, take the network offline at the switch or router [1].
- [ ] Isolate critical systems first: the ones you need to take payments, serve customers or run payroll [1].
- [ ] Power a machine down **only** if you cannot disconnect it. Powering off loses evidence in memory [1].
- [ ] Coordinate by phone, not email or chat, in case the attacker is watching [1].
- [ ] Disconnect backup drives that are still plugged in. Do not plug backups into anything until the network is clean.

## Step 2: Get help and report (first hour)

- [ ] Call your cyber insurer's claims line. Write the claim number in the log.
- [ ] Call your IT provider. If they do not do incident response, ask your insurer who they recommend.
- [ ] Report it. CISA's guide lists CISA, your local FBI field office, the FBI's IC3 and the U.S. Secret Service as places to report and ask for help [1]. CISA's reporting page is cisa.gov/report, and its phone line is 1-844-729-2472 [1][3]. IC3 is at ic3.gov [17].
- [ ] Ask law enforcement whether a decryptor exists. CISA advises consulting federal law enforcement about possible decryptors even if you can recover without one [1].
- [ ] If personal data may have been taken, talk to a lawyer about notification. CISA notes that ransomware actors may steal data before encrypting it and threaten to publish it [1].

## Step 3: Work out what was hit

- [ ] List every affected computer, server and cloud account on the incident tracker.
- [ ] Also list what looks **un**affected, so you can bring it back later in a sensible order [1].
- [ ] Note what kind of data was on affected systems: customer records, payroll, health, card data.
- [ ] Take a photo of the ransom note. Do not contact the attackers.

## Step 4: Decide on recovery

The decision maker makes these calls, with the insurer and IT provider. Log each one in the decision log.

- [ ] **Restore from backups?** Only from backups you know were offline or untouched. CISA advises restoring from offline, encrypted backups and taking care not to reinfect clean systems [1].
- [ ] **Rebuild instead of clean?** CISA's checklist calls for rebuilding systems from clean images where possible, in priority order [1].
- [ ] **Paying is a last resort, and not your call alone.** OFAC strongly discourages paying and says there is no guarantee you get your data back or avoid further attacks [5]. If anyone raises it, it goes to your insurer, lawyer and law enforcement first.

## Step 5: Before you reconnect

- [ ] Reset passwords for affected systems and accounts, once the environment is clean [1].
- [ ] Patch whatever let them in, if you know.
- [ ] Turn on multifactor authentication for email, remote access and admin accounts if it is not on.
- [ ] Bring systems back in priority order, one at a time, watching for anything odd [1].

## Step 6: Close out

- [ ] The incident lead declares it over and writes the date in the log [1].
- [ ] Hold the review described in "How to use this kit".
