# 1. The first 30 minutes

Use this when something looks wrong and you do not yet know what it is: a strange pop-up, a staff member who clicked a link and typed a password, files that will not open, a bank asking about a payment you did not make.

## Minutes 0 to 5: stop and get the right people

- [ ] **Do not wipe, reinstall, or switch anything off.** Leave it as it is for now.
- [ ] **Call, do not email,** your incident lead and your IT provider. Use the phone numbers on the paper contact sheet.
- [ ] **Start the decision log** (section 8). Write the time and what was first noticed, by whom.

## Minutes 5 to 15: contain

- [ ] **Unplug the network cable or turn off Wi-Fi** on any computer that looks affected. CISA's first containment step is to isolate affected systems, and to power a device down only if you cannot disconnect it [1].
- [ ] **If many machines look affected, take the whole network offline** at the switch or router [1].
- [ ] **If a password was typed into a fake page, change that password now from a clean device** and sign that account out of all sessions. See section 3 for email accounts.
- [ ] **If money may have moved, call your bank now.** The FBI's IC3 says that if you discover a fraudulent transfer, time is of the essence: contact your financial institution right away and ask for a recall of the funds [4].

## Minutes 15 to 30: decide what kind of incident this is

- [ ] Files encrypted or a ransom note: go to **section 2, Ransomware**.
- [ ] Mail sent that nobody wrote, odd inbox rules, or a reset you did not ask for: go to **section 3, Hacked email**.
- [ ] A device is missing: go to **section 4, Lost or stolen laptop**.
- [ ] A supplier says it was breached: go to **section 5, Vendor breach notice**.
- [ ] **Call your cyber insurer** if you have a policy, before you hire outside help, and write down the claim number.
- [ ] **Tell staff only what they need,** by phone or in person: "Do not use X until we say so. Do not post about it." Template 6.1 has the wording.

## Do not

- Pay a ransom or reply to the attacker before talking to your insurer, a lawyer and law enforcement. The U.S. Treasury's OFAC strongly discourages ransom payments and warns that paying can carry sanctions risk [5].
- Post about the incident publicly.
- Delete suspicious emails. Move them to a folder; an investigator may need them.
