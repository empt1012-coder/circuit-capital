# 7. Contact sheet

Fill this in now. Print it. Keep one copy in the office and one with the incident lead at home. Update it when people or providers change. Last updated: [date].

## Our people

| Role | Name | Mobile | Backup person | Backup mobile |
|---|---|---|---|---|
| Incident lead | | | | |
| Decision maker | | | | |
| Hands on keyboard (IT) | | | | |
| Communications | | | | |
| Finance (payments, bank) | | | | |

## Outside help

| Who | Company / name | 24-hour phone | Account or policy number | Notes |
|---|---|---|---|---|
| Cyber insurer, claims line | | | | Call before hiring anyone, if your policy says so |
| Insurance broker | | | | |
| IT provider / MSP | | | | |
| Incident response firm | | | | Ask your insurer for their list |
| Lawyer (privacy / data breach) | | | | |
| Bank, fraud line | | | | For payment recalls |
| Microsoft 365 or Google Workspace admin / reseller | | | | |
| Domain registrar | | | | |
| Internet provider | | | | |
| Payroll provider | | | | |
| Accountant | | | | |

## Reporting

| Who | How | Notes |
|---|---|---|
| CISA | cisa.gov/report or 1-844-729-2472 [1][3] | Report and ask for help |
| FBI IC3 | ic3.gov [17] | Fraud, business email compromise, ransomware |
| Local FBI field office | fbi.gov/contact-us/field-offices [1] | Write the number here: |
| Local police (non-emergency) | | For stolen devices |
| UK only: NCSC / Report Fraud | Live attack: 0300 123 2040, 24/7 [10] | |

## Where things are

| Item | Location |
|---|---|
| Admin accounts list (who has admin to what) | |
| Backup location and how to restore | |
| Insurance policy document | |
| Asset list (devices and serial numbers) | |
| This kit (paper copy) | |
