# How to use this kit

This kit is for a small team with no security staff: an owner, an office manager, or the one person who "does the IT". It covers four common incidents and gives you the forms to keep track while it happens.

It is a checklist, not legal, insurance or forensic advice. When a step says "call your insurer" or "talk to a lawyer", that is the step. Numbers in square brackets, like [1], point to the sources at the end of the kit.

## What is inside

| Section | Use it when |
|---|---|
| 1. The first 30 minutes | Anything looks wrong and you are not sure yet what it is |
| 2. Ransomware | Files are encrypted, renamed, or a ransom note appears |
| 3. Hacked email account | A Microsoft 365 or Google Workspace mailbox sends mail nobody wrote, or has rules nobody made |
| 4. Lost or stolen laptop | A work laptop (or phone with work email) is missing |
| 5. Vendor breach notice | A supplier tells you they were breached, or you read it in the news |
| 6. Message templates | You need to tell staff, customers or a vendor something quickly |
| 7. Contact sheet | Fill in now, print, keep a paper copy |
| 8. Decision log | Start it the moment an incident begins |
| 9. Sources | Where each step comes from |

## Do these four things before you need the kit

1. **Fill in the contact sheet (section 7) and print it.** If email or the network is down, the copy on the shared drive is no help. Keep one paper copy in the office and one at home with the incident lead.
2. **Find your cyber insurance policy, if you have one.** Write the claims phone number and policy number on the contact sheet. Read the part about what to do after an incident. Some policies expect you to tell them before you hire anyone; check yours.
3. **Know where your backups are and that they restore.** CISA advises keeping offline, encrypted backups of critical data and testing that they restore, because many ransomware variants look for and delete or encrypt backups they can reach [1].
4. **Know who can reset passwords.** Write down who holds admin access to Microsoft 365 or Google Workspace, your domain registrar, your bank portal and your accounting system.

## Four roles, even if one person holds all of them

- **Incident lead.** Runs the response, keeps the decision log, decides when it is over.
- **Hands on keyboard.** Your IT provider, MSP, or the person who knows the systems.
- **Decision maker.** The owner or whoever can approve spending, shutting systems down, and calls to the insurer, lawyer or police.
- **Communications.** Tells staff what to do, and handles customers and vendors once the decision maker agrees on the message.

## Three rules that apply to every incident

1. **Contain, but do not destroy evidence.** Disconnect affected machines from the network rather than wiping or switching them off. CISA says to power down only if you cannot disconnect a device, because powering off loses evidence held in memory [1]. The FTC gives the same advice: take affected equipment offline, but don't turn machines off until forensic experts arrive [11].
2. **Talk out of band.** If someone may be inside your email or chat, assume they can read it. CISA advises using out-of-band methods such as phone calls while you isolate systems, so you do not tip off the attacker [1].
3. **Write it down as you go.** Use the decision log (section 8). Times, what you saw, what you did, who decided. Your insurer, lawyer and any investigator will ask for this.

## After it is over

- Hold a 30-minute review within two weeks. What happened, what worked, what was slow, what you will change. CISA lists documenting lessons learned as part of recovery [1].
- Update this kit: contacts that were wrong, steps you added.
- Keep the decision log and any reports with your records.
